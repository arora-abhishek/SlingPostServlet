
import org.apache.sling.scripting.sightly.pojo.Use;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.scripting.SlingScriptHelper;

import javax.script.Bindings;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class ListRetriever implements Use {

    List childList = new ArrayList<>();

    @Override
    public void init(Bindings bindings) {

        ResourceResolver resolver = (ResourceResolver) bindings.get("resolver");
        Iterator<Resource> res = resolver.getResource("/content/page/Order").listChildren();
        
        while (res.hasNext()) {
            childList.add(res.next());
        }

        
    }

    public List getChildList() {
        return childList;
    }
}
